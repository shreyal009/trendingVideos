<?php
/**
 * @file 
 * Contains \Drupal\trending\VideoService
 */

namespace Drupal\trending;

use Drupal\Core\Database\Database;
use Drupal\node\Entity\Node;

/**
 * Defines a Service for Downloading Videos from Youtube through tags
 */
class VideoService {
  /**
   * Constructor
   */
  public function __construct() {
    

  }

  public function getVideo(FormStateInterface $form_state) {
  	$DEVELOPER_KEY = 'AIzaSyA_bvWx5J64kOEGh-mzJpyxpAVFmWw6cpw';
    $tags = $form_state->getValue('trending_tags');
    $client = new Google_Client();
    $client->setDeveloperKey($DEVELOPER_KEY);

    // Define an object that will be used to make all API requests.
    $youtube = new Google_Service_YouTube($client);

    
    // Call the search.list method to retrieve results matching the specified
    // query term.
    $searchResponse = $youtube->search->listSearch('id,snippet', array(
      'type' => 'video',
      'q' => $tags,
      'maxResults' => 20,
    ));

    $videoResults = array();
    # Merge video ids
    foreach ($searchResponse['items'] as $searchResult) {
      array_push($videoResults, $searchResult['id']['videoId']);
    }
    $videoIds = join(',', $videoResults);

    # Call the videos.list method to retrieve location details for each video.
    $videosResponse = $youtube->videos->listVideos('snippet, recordingDetails', array(
    'id' => $videoIds,
    ));

    $videos = '';
    $node_entity_type = \Drupal::entityTypeManager()->getDefinition('node');
    // Display the list of matching videos.
    foreach ($videosResponse['items'] as $videoResult) {
      $videos .= $videoResult['snippet']['title'];
      $node = new Node([
        $node_entity_type->getKey('bundle') => 'youtube_videos',
        $node_entity_type->getKey('label') => 'Video',
        'field_tagsvideo' => $tags,
        'field_videos' => $videoResult['snippet']['title'],
        ]);
       $node->save();

     }

    return true;



}
?>

  }
}