<?php
/**
 * @file
 * Contains \Drupal\rsvplist\Form\RSVPSettingsForm
 */

namespace Drupal\trending\Form;

use Drupal\Core\Form\ConfigFormBase;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;

/**
 * Defines a form to add tags to the module settings
 */
class TRENDINGSettingsForm extends ConfigFormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormID() {
    return 'trending_admin_settings';
  }
   /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
    'trending.settings'
    ];
  }
  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Request $request = NULL) {
    $form['trending_tags'] = array(
      '#type' => 'textfield',
      '#size' => 25,
      '#title' => $this->t('The Youtube Video tags to be added'),
      '#default_value' => t('Enter here'),
      '#description' => t('Add tags here to be added in the taxonomy and related videos to it '),
      '#required' => TRUE,
       );
    
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => t('Add Tag'),
      );

    return $form;
  }

   /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $value = $form_state->getValue('trending_tags');
    $query = \Drupal::entityQuery('taxonomy_term');
    $query->condition('vid', "Tags");
    $query->condition('name', $value);
    $results = $query->execute();
    if ($results){
      // We found a row with tag already defined.
      $form_state->setErrorByName('tag', t('The tag %tag is already subscribed to this list.', array('%tag' => $value)));
    }

  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $value = $form_state->getValue('trending_tags');
    $term = \Drupal\taxonomy\Entity\Term::create([
          'vid' => 'Tags',
          'name' => $value,
    ]);
    $term->save();
    /** @var \Drupal\trending\VideoService $videoservice **/
    $videoservice = \Drupal::service('trending.videoservice');
    if($videoservice->getVideo($form_state)) {
      drupal_set_message('loaded');
    }
    drupal_set_message('Thank You the tag has been added');
  }

}



